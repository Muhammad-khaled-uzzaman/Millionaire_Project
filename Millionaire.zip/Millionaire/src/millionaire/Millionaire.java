/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package millionaire;

import java.awt.Color;
import static java.awt.Color.BLACK;
import static java.awt.Color.GREEN;
import static java.awt.Color.WHITE;
import static java.lang.Thread.sleep;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author pc
 */
public class Millionaire extends javax.swing.JFrame {

    /**
     * Creates new form Millionaire
     */
    int callquestion;
    static int milliseconds = 0;
    static int seconds = 0;
    static boolean state = true;

    public void init() {
        callquestion = 0;
    }

    public Millionaire() {
        initComponents();
    }

    @SuppressWarnings("unchecked")

    int count = 0;
    String[] imagename = {"Picture01.png"};
    int people = 0;
    String[] impeople = {"jpgePeopleX.jpg"};
    int phone = 0;
    String[] pnpeople = {"jpgePhoneX.jpg"};
    int fifty = 0;
    String[] fifpeople = {"jpge50X.jpg"};
    int correct00 = 0;
    String[] imCorrect00 = {"Picture01.png"};
    int correct0 = 0;
    String[] imCorrect0 = {"Picture1.png"};
    int correct1 = 0;
    String[] imCorrect1 = {"Picture2.png"};
    int correct2 = 0;
    String[] imCorrect2 = {"Picture3.png"};
    int correct3 = 0;
    String[] imCorrect3 = {"Picture4.png"};
    int correct4 = 0;
    String[] imCorrect4 = {"Picture5.png"};
    int correct5 = 0;
    String[] imCorrect5 = {"Picture6.png"};
    int correct6 = 0;
    String[] imCorrect6 = {"Picture7.png"};
    int correct7 = 0;
    String[] imCorrect7 = {"Picture8.png"};
    int correct8 = 0;
    String[] imCorrect8 = {"Picture9.png"};
    int correct9 = 0;
    String[] imCorrect9 = {"Picture10.png"};
    int correct10 = 0;
    String[] imCorrect10 = {"Picture11.png"};
    int correct11 = 0;
    String[] imCorrect11 = {"Picture12.png"};
    int correct12 = 0;
    String[] imCorrect12 = {"Picture13.png"};
    int correct13 = 0;
    String[] imCorrect13 = {"Picture14.png"};
    int correct14 = 0;
    String[] imCorrect14 = {"Picture15.png"};
    int con = 0;
    String[] congra = {"pic.jpg"};


    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        tf1 = new javax.swing.JTextField();
        tf2 = new javax.swing.JTextField();
        tf5 = new javax.swing.JTextField();
        tf4 = new javax.swing.JTextField();
        tf3 = new javax.swing.JTextField();
        second = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBounds(new java.awt.Rectangle(0, 0, 1100, 900));
        addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                formMouseMoved(evt);
            }
        });
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
        });

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/millionaire/image/jpgePhone.jpg"))); // NOI18N
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/millionaire/image/jpge50.jpg"))); // NOI18N
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
        });

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/millionaire/image/Picture0.png"))); // NOI18N

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/millionaire/image/jpgePeople.jpg"))); // NOI18N
        jLabel6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel6MouseClicked(evt);
            }
        });

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/millionaire/image/imagesCAG5P2IF.jpg"))); // NOI18N
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        tf1.setBackground(new java.awt.Color(0, 0, 0));
        tf1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        tf1.setForeground(new java.awt.Color(255, 255, 255));
        tf1.setCaretColor(new java.awt.Color(0, 0, 204));

        tf2.setBackground(new java.awt.Color(0, 0, 0));
        tf2.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        tf2.setForeground(new java.awt.Color(255, 255, 255));
        tf2.setCaretColor(new java.awt.Color(0, 0, 102));
        tf2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tf2MouseClicked(evt);
            }
        });

        tf5.setBackground(new java.awt.Color(0, 0, 0));
        tf5.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        tf5.setForeground(new java.awt.Color(255, 255, 255));
        tf5.setCaretColor(new java.awt.Color(0, 0, 102));
        tf5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tf5MouseClicked(evt);
            }
        });

        tf4.setBackground(new java.awt.Color(0, 0, 0));
        tf4.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        tf4.setForeground(new java.awt.Color(255, 255, 255));
        tf4.setCaretColor(new java.awt.Color(0, 0, 102));
        tf4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tf4MouseClicked(evt);
            }
        });

        tf3.setBackground(new java.awt.Color(0, 0, 0));
        tf3.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        tf3.setForeground(new java.awt.Color(255, 255, 255));
        tf3.setCaretColor(new java.awt.Color(0, 0, 153));
        tf3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tf3MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                tf3MouseEntered(evt);
            }
        });

        second.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        second.setForeground(new java.awt.Color(255, 255, 255));
        second.setText("00");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel6)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel3)
                        .addGap(126, 126, 126))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(33, 33, 33)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(tf4, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(tf5, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(tf2, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(tf3, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(tf1, javax.swing.GroupLayout.PREFERRED_SIZE, 516, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel1))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(177, 177, 177)
                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 276, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(271, 271, 271)
                                .addComponent(second, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 82, Short.MAX_VALUE)))
                .addComponent(jLabel4)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addComponent(jLabel3)
                            .addComponent(jLabel2))
                        .addGap(34, 34, 34)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(second, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(tf1, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tf2, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tf3, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(13, 13, 13)
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tf4, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tf5, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void formMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseMoved
        // TODO add your handling code here:
        this.getContentPane().setBackground(Color.black);
    }//GEN-LAST:event_formMouseMoved

    private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
        // TODO add your handling code here:
        tf1.setText("Who Wants to be a Millionaire");

        tf2.setText("       ");
        tf3.setText("       ");
        tf4.setText("       ");
        tf5.setText("       ");

    }//GEN-LAST:event_formWindowActivated

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked
        // TODO add your handling code here:
        callquestion = callquestion + 1;
        tf1.setForeground(WHITE);
        tf2.setForeground(WHITE);
        tf3.setForeground(WHITE);
        tf4.setForeground(WHITE);
        tf5.setForeground(WHITE);
        if (callquestion == 1) {
            tf1.setText("What is 9 + 4 ?");
            tf2.setText("A) 36");
            tf3.setText("B) 13");
            tf4.setText("C) 45");
            tf5.setText("D) 62");
        }

        if (callquestion == 2) {
            tf3.setBackground(BLACK);
            tf1.setText("What is 2 + 18 + 16 ?");
            tf2.setText("A) 36");
            tf3.setText("B) 18");
            tf4.setText("C) 45");
            tf5.setText("D) 67");
        }
        if (callquestion == 3) {
            tf2.setBackground(BLACK);
            tf1.setText("What is 10 + 15 + 20 ?");
            tf2.setText("A) 67");
            tf3.setText("B) 18");
            tf4.setText("C) 36");
            tf5.setText("D) 45");
        }
        if (callquestion == 4) {
            tf5.setBackground(BLACK);
            tf1.setText("What is 4 + 1 + 18 ?");
            tf2.setText("A) 36");
            tf3.setText("B) 18");
            tf4.setText("C) 23");
            tf5.setText("D) 62");
        }
        if (callquestion == 5) {
            tf4.setBackground(BLACK);
            tf1.setText("What is 4 + 5 + 18 ?");
            tf2.setText("A) 36");
            tf3.setText("B) 13");
            tf4.setText("C) 45");
            tf5.setText("D) 27");
        }
        if (callquestion == 6) {
            tf5.setBackground(BLACK);
            tf1.setText("What is 9 + 1");
            tf2.setText("A) 6");
            tf3.setText("B) 13");
            tf4.setText("C) 10");
            tf5.setText("D) 2");
        }
        if (callquestion == 7) {
            tf4.setBackground(BLACK);
            tf1.setText("What is 19 + 24");
            tf2.setText("A) 20");
            tf3.setText("B) 43");
            tf4.setText("C) 5");
            tf5.setText("D) 162");
        }
        if (callquestion == 8) {
            tf3.setBackground(BLACK);
            tf1.setText("What is 9 + 4 + 8");
            tf2.setText("A) 21");
            tf3.setText("B) 13");
            tf4.setText("C) 45");
            tf5.setText("D) 62");
        }
        if (callquestion == 9) {
            tf2.setBackground(BLACK);
            tf1.setText("What is 9 * 4");
            tf2.setText("A) 36");
            tf3.setText("B) 13");
            tf4.setText("C) 45");
            tf5.setText("D) 62");
        }
        if (callquestion == 10) {
            tf2.setBackground(BLACK);
            tf1.setText("What is 19 - 4");
            tf2.setText("A) 15");
            tf3.setText("B) 13");
            tf4.setText("C) 45");
            tf5.setText("D) 62");
        }
        if (callquestion == 11) {
            tf2.setBackground(BLACK);
            tf1.setText("What is 109 + 4");
            tf2.setText("A) 136");
            tf3.setText("B) 134");
            tf4.setText("C) 113");
            tf5.setText("D) 114");
        }
        if (callquestion == 12) {
            tf4.setBackground(BLACK);
            tf1.setText("What is 18 + 4");
            tf2.setText("A) 36");
            tf3.setText("B) 13");
            tf4.setText("C) 45");
            tf5.setText("D) 22");
        }
        if (callquestion == 13) {
            tf5.setBackground(BLACK);
            tf1.setText("What is 50 * 2");
            tf2.setText("A) 100");
            tf3.setText("B) 13");
            tf4.setText("C) 45");
            tf5.setText("D) 62");
        }
        if (callquestion == 14) {
            tf2.setBackground(BLACK);
            tf1.setText("What is 4 + 4 * 2");
            tf2.setText("A) 36");
            tf3.setText("B) 12");
            tf4.setText("C) 45");
            tf5.setText("D) 62");
        }
        if (callquestion == 15) {
            tf2.setBackground(BLACK);
            tf1.setText("What is 30 / 2");
            tf2.setText("A) 36");
            tf3.setText("B) 13");
            tf4.setText("C) 15");
            tf5.setText("D) 62");
        }
    }//GEN-LAST:event_jButton1MouseClicked

    private void jLabel6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel6MouseClicked
        // TODO add your handling code here:
        ImageIcon[] imagesList = new ImageIcon[1];
        for (int i = 0; i < imagesList.length; i++) {
            imagesList[i] = new ImageIcon(getClass().getResource("/Millionaire/image/" + impeople[i]));
        }
        if (people < 0) {
            people = 1;
        }
        if (people >= 0 && people < impeople.length) {
            jLabel6.setIcon(imagesList[people]);

            people++;
        }

        if (callquestion == 1 && jLabel6.isFocusable()) {
            JOptionPane.showMessageDialog(this, "People Vote\nA  =  2%\nB  =  90%\nC  =  5%\nD  =  3%  ");
        }
        if (callquestion == 2 && jLabel6.isFocusable()) {
            JOptionPane.showMessageDialog(this, "People Vote\nA  =  92%\nB  =  2%\nC  =  5%\nD  =  1%  ");
        }
        if (callquestion == 3 && jLabel6.isFocusable()) {
            JOptionPane.showMessageDialog(this, "People Vote\nA  =  2%\nB  =  2%\nC  =  5%\nD  =  91%  ");
        }
        if (callquestion == 4 && jLabel6.isFocusable()) {
            JOptionPane.showMessageDialog(this, "People Vote\nA  =  0%\nB  =  2%\nC  =  95%\nD  =  3%  ");
        }
        if (callquestion == 5 && jLabel6.isFocusable()) {
            JOptionPane.showMessageDialog(this, "People Vote\nA  =  2%\nB  =  2%\nC  =  5%\nD  =  91%  ");
        }
        if (callquestion == 6 && jLabel6.isFocusable()) {
            JOptionPane.showMessageDialog(this, "People Vote\nA  =  0%\nB  =  2%\nC  =  95%\nD  =  3%  ");
        }
        if (callquestion == 7 && jLabel6.isFocusable()) {
            JOptionPane.showMessageDialog(this, "People Vote\nA  =  0%\nB  =  92%\nC  =  5%\nD  =  3%  ");
        }
        if (callquestion == 8 && jLabel6.isFocusable()) {
            JOptionPane.showMessageDialog(this, "People Vote\nA  =  90%\nB  =  2%\nC  =  5%\nD  =  3%  ");
        }
        if (callquestion == 9 && jLabel6.isFocusable()) {
            JOptionPane.showMessageDialog(this, "People Vote\nA  =  90%\nB  =  2%\nC  =  5%\nD  =  3%  ");
        }
        if (callquestion == 10 && jLabel6.isFocusable()) {
            JOptionPane.showMessageDialog(this, "People Vote\nA  =  90%\nB  =  2%\nC  =  5%\nD  =  3%  ");
        }
        if (callquestion == 11 && jLabel6.isFocusable()) {
            JOptionPane.showMessageDialog(this, "People Vote\nA  =  9%\nB  =  2%\nC  =  86%\nD  =  3%  ");
        }
        if (callquestion == 12 && jLabel6.isFocusable()) {
            JOptionPane.showMessageDialog(this, "People Vote\nA  =  0%\nB  =  2%\nC  =  5%\nD  =  93%  ");
        }
        if (callquestion == 13 && jLabel6.isFocusable()) {
            JOptionPane.showMessageDialog(this, "People Vote\nA  =  90%\nB  =  2%\nC  =  5%\nD  =  3%  ");
        }
        if (callquestion == 14 && jLabel6.isFocusable()) {
            JOptionPane.showMessageDialog(this, "People Vote\nA  =  0%\nB  =  92%\nC  =  5%\nD  =  3%  ");
        }
        if (callquestion == 15 && jLabel6.isFocusable()) {
            JOptionPane.showMessageDialog(this, "People Vote\nA  =  0%\nB  =  92%\nC  =  5%\nD  =  3%  ");
        }

    }//GEN-LAST:event_jLabel6MouseClicked

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
        // TODO add your handling code here:
        ImageIcon[] imagesList = new ImageIcon[1];
        for (int i = 0; i < imagesList.length; i++) {
            imagesList[i] = new ImageIcon(getClass().getResource("/Millionaire/image/" + pnpeople[0]));
        }
        if (phone < 0) {
            phone = 1;
        }
        if (phone >= 0 && phone < pnpeople.length) {
            jLabel2.setIcon(imagesList[phone]);

            phone++;
        }

        if (callquestion == 1 && jLabel2.isFocusable()) {
            tf3.setForeground(Color.blue);
        }
        if (callquestion == 2 && jLabel3.isFocusable()) {
            tf2.setForeground(Color.BLUE);

        }
        if (callquestion == 3 && jLabel3.isFocusable()) {
            tf5.setForeground(Color.BLUE);

        }
        if (callquestion == 4 && jLabel3.isFocusable()) {
            tf4.setForeground(Color.BLUE);

        }
        if (callquestion == 5 && jLabel3.isFocusable()) {
            tf5.setForeground(Color.BLUE);

        }
        if (callquestion == 6 && jLabel3.isFocusable()) {
            tf4.setForeground(Color.BLUE);

        }
        if (callquestion == 7 && jLabel3.isFocusable()) {
            tf3.setForeground(Color.BLUE);

        }
        if (callquestion == 8 && jLabel3.isFocusable()) {
            tf2.setForeground(Color.BLUE);

        }
        if (callquestion == 9 && jLabel3.isFocusable()) {
            tf2.setForeground(Color.BLUE);

        }
        if (callquestion == 10 && jLabel3.isFocusable()) {
            tf2.setForeground(Color.BLUE);

        }
        if (callquestion == 11 && jLabel3.isFocusable()) {
            tf4.setForeground(Color.BLUE);

        }
        if (callquestion == 12 && jLabel3.isFocusable()) {
            tf5.setForeground(Color.BLUE);

        }
        if (callquestion == 13 && jLabel3.isFocusable()) {
            tf2.setForeground(Color.BLUE);

        }
        if (callquestion == 14 && jLabel3.isFocusable()) {
            tf3.setForeground(Color.BLUE);

        }
        if (callquestion == 15 && jLabel3.isFocusable()) {
            tf4.setForeground(Color.BLUE);

        }

    }//GEN-LAST:event_jLabel2MouseClicked

    private void jLabel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseClicked
        ImageIcon[] imagesList = new ImageIcon[1];
        for (int i = 0; i < imagesList.length; i++) {
            imagesList[i] = new ImageIcon(getClass().getResource("/Millionaire/image/" + fifpeople[0]));
        }
        if (fifty < 0) {
            fifty = 1;
        }
        if (fifty >= 0 && fifty < fifpeople.length) {
            jLabel3.setIcon(imagesList[fifty]);

            fifty++;
        }

        if (callquestion == 1 && jLabel3.isFocusable()) {

            tf4.setForeground(BLACK);
            tf5.setForeground(BLACK);
        } else if (callquestion == 2 && jLabel3.isFocusable()) {
            tf3.setForeground(BLACK);
            tf5.setForeground(BLACK);
        } else if (callquestion == 3 && jLabel3.isFocusable()) {
            tf2.setForeground(BLACK);
            tf3.setForeground(BLACK);
            fifty = 1;
        } else if (callquestion == 4 && jLabel3.isFocusable()) {
            tf2.setForeground(BLACK);
            tf3.setForeground(BLACK);
        } else if (callquestion == 5 && jLabel3.isFocusable()) {
            tf2.setForeground(BLACK);
            tf4.setForeground(BLACK);
        } else if (callquestion == 6 && jLabel3.isFocusable()) {
            tf2.setForeground(BLACK);
            tf3.setForeground(BLACK);
        } else if (callquestion == 7 && jLabel3.isFocusable()) {
            tf5.setForeground(BLACK);
            tf2.setForeground(BLACK);
        } else if (callquestion == 8 && jLabel3.isFocusable()) {
            tf4.setForeground(BLACK);
            tf3.setForeground(BLACK);
        } else if (callquestion == 9 && jLabel3.isFocusable()) {
            tf5.setForeground(BLACK);
            tf3.setForeground(BLACK);
        } else if (callquestion == 10 && jLabel3.isFocusable()) {
            tf4.setForeground(BLACK);
            tf3.setForeground(BLACK);
        } else if (callquestion == 11 && jLabel3.isFocusable()) {
            tf2.setForeground(BLACK);
            tf3.setForeground(BLACK);
        }
        if (callquestion == 12 && jLabel3.isFocusable()) {
            tf2.setForeground(BLACK);
            tf3.setForeground(BLACK);
        } else if (callquestion == 13 && jLabel3.isFocusable()) {
            tf5.setForeground(BLACK);
            tf3.setForeground(BLACK);
        } else if (callquestion == 14 && jLabel3.isFocusable()) {
            tf2.setForeground(BLACK);
            tf5.setForeground(BLACK);
        } else if (callquestion == 15 && jLabel3.isFocusable()) {
            tf2.setForeground(BLACK);
            tf4.setForeground(BLACK);
        }
    }//GEN-LAST:event_jLabel3MouseClicked

    private void tf3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tf3MouseClicked
        if (callquestion == 1 && tf3.isFocusable()) {
            tf3.setOpaque(true);
            tf3.setForeground(BLACK);
            tf3.setBackground(GREEN);

            tf2.setOpaque(true);
            tf2.setForeground(WHITE);
            tf2.setBackground(BLACK);

            tf4.setOpaque(true);
            tf4.setForeground(WHITE);
            tf4.setBackground(BLACK);

            tf5.setOpaque(true);
            tf5.setForeground(WHITE);
            tf5.setBackground(BLACK);

            ImageIcon[] imagesList = new ImageIcon[1];
            for (int i = 0; i < imagesList.length; i++) {
                imagesList[i] = new ImageIcon(getClass().getResource("/Millionaire/image/" + imCorrect0[i]));
            }
            if (correct0 < 0) {
                correct0 = 1;
            }
            if (correct0 >= 0 && correct0 < imCorrect0.length) {
                jLabel4.setIcon(imagesList[correct0]);

                correct0++;
            }
        }

        if (callquestion == 2 && tf3.isFocusable()) {
            tf3.setOpaque(true);
            tf3.setForeground(BLACK);
            tf3.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 100 pounds");
            System.exit(0);
        }
        if (callquestion == 3 && tf3.isFocusable()) {
            tf3.setOpaque(true);
            tf3.setForeground(BLACK);
            tf3.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 200 pounds");
            System.exit(0);
        }
        if (callquestion == 4 && tf3.isFocusable()) {
            tf3.setOpaque(true);
            tf3.setForeground(BLACK);
            tf3.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 300 pounds");
            System.exit(0);
        }
        if (callquestion == 5 && tf3.isFocusable()) {
            tf3.setOpaque(true);
            tf3.setForeground(BLACK);
            tf3.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 500 pounds");
            System.exit(0);
        }
        if (callquestion == 6 && tf3.isFocusable()) {
            tf3.setOpaque(true);
            tf3.setForeground(BLACK);
            tf3.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 100 pounds");
            System.exit(0);
        }
        if (callquestion == 7 && tf3.isFocusable()) {
            tf3.setOpaque(true);
            tf3.setForeground(BLACK);
            tf3.setBackground(GREEN);

            tf2.setOpaque(true);
            tf2.setForeground(WHITE);
            tf2.setBackground(BLACK);

            tf4.setOpaque(true);
            tf4.setForeground(WHITE);
            tf4.setBackground(BLACK);

            tf5.setOpaque(true);
            tf5.setForeground(WHITE);
            tf5.setBackground(BLACK);

            ImageIcon[] imagesList = new ImageIcon[1];
            for (int i = 0; i < imagesList.length; i++) {
                imagesList[i] = new ImageIcon(getClass().getResource("/Millionaire/image/" + imCorrect6[i]));
            }
            if (correct6 < 0) {
                correct6 = 1;
            }
            if (correct6 >= 0 && correct6 < imCorrect6.length) {
                jLabel4.setIcon(imagesList[correct6]);

                correct6++;
            }
        }
        if (callquestion == 8 && tf3.isFocusable()) {
            tf3.setOpaque(true);
            tf3.setForeground(BLACK);
            tf3.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 4000 pounds");
            System.exit(0);
        }
        if (callquestion == 9 && tf3.isFocusable()) {
            tf3.setOpaque(true);
            tf3.setForeground(BLACK);
            tf3.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 8000 pounds");
            System.exit(0);
        }
        if (callquestion == 10 && tf3.isFocusable()) {
            tf3.setOpaque(true);
            tf3.setForeground(BLACK);
            tf3.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 16000 pounds");
            System.exit(0);
        }
        if (callquestion == 11 && tf3.isFocusable()) {
            tf3.setOpaque(true);
            tf3.setForeground(BLACK);
            tf3.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 32000 pounds");
            System.exit(0);
        }
        if (callquestion == 12 && tf3.isFocusable()) {
            tf3.setOpaque(true);
            tf3.setForeground(BLACK);
            tf3.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 64000 pounds");
            System.exit(0);
        }
        if (callquestion == 13 && tf3.isFocusable()) {
            tf3.setOpaque(true);
            tf3.setForeground(BLACK);
            tf3.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 125000 pounds");
            System.exit(0);
        }
        if (callquestion == 14 && tf2.isFocusable()) {
            tf2.setOpaque(true);
            tf2.setForeground(BLACK);
            tf2.setBackground(GREEN);

            tf3.setOpaque(true);
            tf3.setForeground(WHITE);
            tf3.setBackground(BLACK);

            tf4.setOpaque(true);
            tf4.setForeground(WHITE);
            tf4.setBackground(BLACK);

            tf5.setOpaque(true);
            tf5.setForeground(WHITE);
            tf5.setBackground(BLACK);

            ImageIcon[] imagesList = new ImageIcon[1];
            for (int i = 0; i < imagesList.length; i++) {
                imagesList[i] = new ImageIcon(getClass().getResource("/Millionaire/image/" + imCorrect13[i]));
            }
            if (correct13 < 0) {
                correct13 = 1;
            }
            if (correct13 >= 0 && correct13 < imCorrect13.length) {
                jLabel4.setIcon(imagesList[correct13]);

                correct13++;
            }
        }
        if (callquestion == 15 && tf3.isFocusable()) {
            tf3.setOpaque(true);
            tf3.setForeground(BLACK);
            tf3.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 500000 pounds");
            System.exit(0);
        }
    }//GEN-LAST:event_tf3MouseClicked

    private void tf2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tf2MouseClicked
        // TODO add your handling code here:
        if (callquestion == 2 && tf2.isFocusable()) {
            tf2.setOpaque(true);
            tf2.setForeground(BLACK);
            tf2.setBackground(GREEN);

            tf3.setOpaque(true);
            tf3.setForeground(WHITE);
            tf3.setBackground(BLACK);

            tf4.setOpaque(true);
            tf4.setForeground(WHITE);
            tf4.setBackground(BLACK);

            tf5.setOpaque(true);
            tf5.setForeground(WHITE);
            tf5.setBackground(BLACK);

            ImageIcon[] imagesList = new ImageIcon[1];
            for (int i = 0; i < imagesList.length; i++) {
                imagesList[i] = new ImageIcon(getClass().getResource("/Millionaire/image/" + imCorrect1[i]));
            }
            if (correct1 < 0) {
                correct1 = 1;
            }
            if (correct1 >= 0 && correct1 < imCorrect1.length) {
                jLabel4.setIcon(imagesList[correct1]);

                correct1++;
            }
        }
        if (callquestion == 1 && tf2.isFocusable()) {
            tf2.setOpaque(true);
            tf2.setForeground(BLACK);
            tf2.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 00.0 pounds");
            System.exit(0);
        }

        if (callquestion == 3 && tf2.isFocusable()) {
            tf2.setOpaque(true);
            tf2.setForeground(BLACK);
            tf2.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 200 pounds");
            System.exit(0);
        }
        if (callquestion == 4 && tf2.isFocusable()) {
            tf2.setOpaque(true);
            tf2.setForeground(BLACK);
            tf2.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 300 pounds");
            System.exit(0);
        }
        if (callquestion == 5 && tf2.isFocusable()) {
            tf2.setOpaque(true);
            tf2.setForeground(BLACK);
            tf2.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 500 pounds");
            System.exit(0);
        }
        if (callquestion == 6 && tf2.isFocusable()) {
            tf2.setOpaque(true);
            tf2.setForeground(BLACK);
            tf2.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 1000 pounds");
            System.exit(0);
        }
        if (callquestion == 7 && tf2.isFocusable()) {
            tf2.setOpaque(true);
            tf2.setForeground(BLACK);
            tf2.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 2000 pounds");
            System.exit(0);
        }
        if (callquestion == 8 && tf2.isFocusable()) {
            tf2.setOpaque(true);
            tf2.setForeground(BLACK);
            tf2.setBackground(GREEN);

            tf3.setOpaque(true);
            tf3.setForeground(WHITE);
            tf3.setBackground(BLACK);

            tf4.setOpaque(true);
            tf4.setForeground(WHITE);
            tf4.setBackground(BLACK);

            tf5.setOpaque(true);
            tf5.setForeground(WHITE);
            tf5.setBackground(BLACK);

            ImageIcon[] imagesList = new ImageIcon[1];
            for (int i = 0; i < imagesList.length; i++) {
                imagesList[i] = new ImageIcon(getClass().getResource("/Millionaire/image/" + imCorrect7[i]));
            }
            if (correct7 < 0) {
                correct7 = 1;
            }
            if (correct7 >= 0 && correct7 < imCorrect7.length) {
                jLabel4.setIcon(imagesList[correct7]);

                correct7++;
            }
        }
        if (callquestion == 9 && tf2.isFocusable()) {
            tf2.setOpaque(true);
            tf2.setForeground(BLACK);
            tf2.setBackground(GREEN);

            tf3.setOpaque(true);
            tf3.setForeground(WHITE);
            tf3.setBackground(BLACK);

            tf4.setOpaque(true);
            tf4.setForeground(WHITE);
            tf4.setBackground(BLACK);

            tf5.setOpaque(true);
            tf5.setForeground(WHITE);
            tf5.setBackground(BLACK);

            ImageIcon[] imagesList = new ImageIcon[1];
            for (int i = 0; i < imagesList.length; i++) {
                imagesList[i] = new ImageIcon(getClass().getResource("/Millionaire/image/" + imCorrect8[i]));
            }
            if (correct8 < 0) {
                correct8 = 1;
            }
            if (correct8 >= 0 && correct8 < imCorrect8.length) {
                jLabel4.setIcon(imagesList[correct8]);

                correct8++;
            }
        }
        if (callquestion == 10 && tf2.isFocusable()) {
            tf2.setOpaque(true);
            tf2.setForeground(BLACK);
            tf2.setBackground(GREEN);

            tf3.setOpaque(true);
            tf3.setForeground(WHITE);
            tf3.setBackground(BLACK);

            tf4.setOpaque(true);
            tf4.setForeground(WHITE);
            tf4.setBackground(BLACK);

            tf5.setOpaque(true);
            tf5.setForeground(WHITE);
            tf5.setBackground(BLACK);

            ImageIcon[] imagesList = new ImageIcon[1];
            for (int i = 0; i < imagesList.length; i++) {
                imagesList[i] = new ImageIcon(getClass().getResource("/Millionaire/image/" + imCorrect9[i]));
            }
            if (correct9 < 0) {
                correct9 = 1;
            }
            if (correct9 >= 0 && correct9 < imCorrect9.length) {
                jLabel4.setIcon(imagesList[correct9]);

                correct9++;
            }
        }
        if (callquestion == 11 && tf2.isFocusable()) {
            tf2.setOpaque(true);
            tf2.setForeground(BLACK);
            tf2.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 32000 pounds");
            System.exit(0);
        }
        if (callquestion == 12 && tf2.isFocusable()) {
            tf2.setOpaque(true);
            tf2.setForeground(BLACK);
            tf2.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 64000 pounds");
            System.exit(0);
        }
        if (callquestion == 13 && tf2.isFocusable()) {
            tf2.setOpaque(true);
            tf2.setForeground(BLACK);
            tf2.setBackground(GREEN);

            tf3.setOpaque(true);
            tf3.setForeground(WHITE);
            tf3.setBackground(BLACK);

            tf4.setOpaque(true);
            tf4.setForeground(WHITE);
            tf4.setBackground(BLACK);

            tf5.setOpaque(true);
            tf5.setForeground(WHITE);
            tf5.setBackground(BLACK);

            ImageIcon[] imagesList = new ImageIcon[1];
            for (int i = 0; i < imagesList.length; i++) {
                imagesList[i] = new ImageIcon(getClass().getResource("/Millionaire/image/" + imCorrect12[i]));
            }
            if (correct12 < 0) {
                correct12 = 1;
            }
            if (correct12 >= 0 && correct12 < imCorrect12.length) {
                jLabel4.setIcon(imagesList[correct12]);

                correct12++;
            }
        }
        if (callquestion == 14 && tf2.isFocusable()) {
            tf2.setOpaque(true);
            tf2.setForeground(BLACK);
            tf2.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 250000 pounds");
            System.exit(0);
        }
        if (callquestion == 15 && tf2.isFocusable()) {
            tf2.setOpaque(true);
            tf2.setForeground(BLACK);
            tf2.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 500000 pounds");
            System.exit(0);
        }
    }//GEN-LAST:event_tf2MouseClicked

    private void tf5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tf5MouseClicked
        // TODO add your handling code here:
        if (callquestion == 3 && tf2.isFocusable()) {
            tf2.setOpaque(true);
            tf2.setForeground(WHITE);
            tf2.setBackground(BLACK);

            tf3.setOpaque(true);
            tf3.setForeground(WHITE);
            tf3.setBackground(BLACK);

            tf4.setOpaque(true);
            tf4.setForeground(WHITE);
            tf4.setBackground(BLACK);

            tf5.setOpaque(true);
            tf5.setForeground(BLACK);
            tf5.setBackground(GREEN);

            ImageIcon[] imagesList = new ImageIcon[1];
            for (int i = 0; i < imagesList.length; i++) {
                imagesList[i] = new ImageIcon(getClass().getResource("/Millionaire/image/" + imCorrect2[i]));
            }
            if (correct2 < 0) {
                correct2 = 1;
            }
            if (correct2 >= 0 && correct2 < imCorrect2.length) {
                jLabel4.setIcon(imagesList[correct2]);

                correct2++;
            }
        }

        if (callquestion == 1 && tf5.isFocusable()) {
            tf5.setOpaque(true);
            tf5.setForeground(BLACK);
            tf5.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 00.0 pounds");
            System.exit(0);
        }
        if (callquestion == 2 && tf5.isFocusable()) {
            tf5.setOpaque(true);
            tf5.setForeground(BLACK);
            tf5.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 100 pounds");
            System.exit(0);
        }
        if (callquestion == 4 && tf5.isFocusable()) {
            tf5.setOpaque(true);
            tf5.setForeground(BLACK);
            tf5.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 200 pounds");
            System.exit(0);
        }
        if (callquestion == 5 && tf5.isFocusable()) {
            tf5.setOpaque(true);
            tf5.setForeground(BLACK);
            tf5.setBackground(GREEN);

            tf3.setOpaque(true);
            tf3.setForeground(WHITE);
            tf3.setBackground(BLACK);

            tf4.setOpaque(true);
            tf4.setForeground(WHITE);
            tf4.setBackground(BLACK);

            tf2.setOpaque(true);
            tf2.setForeground(WHITE);
            tf2.setBackground(BLACK);

            ImageIcon[] imagesList = new ImageIcon[1];
            for (int i = 0; i < imagesList.length; i++) {
                imagesList[i] = new ImageIcon(getClass().getResource("/Millionaire/image/" + imCorrect4[i]));
            }
            if (correct4 < 0) {
                correct4 = 1;
            }
            if (correct4 >= 0 && correct4 < imCorrect4.length) {
                jLabel4.setIcon(imagesList[correct4]);

                correct4++;
            }
        }
        if (callquestion == 6 && tf5.isFocusable()) {
            tf5.setOpaque(true);
            tf5.setForeground(BLACK);
            tf5.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 1000 pounds");
            System.exit(0);
        }
        if (callquestion == 7 && tf5.isFocusable()) {
            tf5.setOpaque(true);
            tf5.setForeground(BLACK);
            tf5.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 2000 pounds");
            System.exit(0);
        }
        if (callquestion == 8 && tf5.isFocusable()) {
            tf5.setOpaque(true);
            tf5.setForeground(BLACK);
            tf5.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 4000 pounds");
            System.exit(0);
        }
        if (callquestion == 9 && tf5.isFocusable()) {
            tf5.setOpaque(true);
            tf5.setForeground(BLACK);
            tf5.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 8000 pounds");
            System.exit(0);
        }
        if (callquestion == 10 && tf5.isFocusable()) {
            tf5.setOpaque(true);
            tf5.setForeground(BLACK);
            tf5.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 16000 pounds");
            System.exit(0);
        }
        if (callquestion == 11 && tf5.isFocusable()) {
            tf5.setOpaque(true);
            tf5.setForeground(BLACK);
            tf5.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 32000 pounds");
            System.exit(0);
        }
        if (callquestion == 12 && tf5.isFocusable()) {
            tf5.setOpaque(true);
            tf5.setForeground(BLACK);
            tf5.setBackground(GREEN);

            tf2.setOpaque(true);
            tf2.setForeground(WHITE);
            tf2.setBackground(BLACK);

            tf4.setOpaque(true);
            tf4.setForeground(WHITE);
            tf4.setBackground(BLACK);

            tf3.setOpaque(true);
            tf3.setForeground(WHITE);
            tf3.setBackground(BLACK);

            ImageIcon[] imagesList = new ImageIcon[1];
            for (int i = 0; i < imagesList.length; i++) {
                imagesList[i] = new ImageIcon(getClass().getResource("/Millionaire/image/" + imCorrect11[i]));
            }
            if (correct11 < 0) {
                correct11 = 1;
            }
            if (correct11 >= 0 && correct11 < imCorrect11.length) {
                jLabel4.setIcon(imagesList[correct11]);

                correct11++;
            }
        }
        if (callquestion == 13 && tf5.isFocusable()) {
            tf5.setOpaque(true);
            tf5.setForeground(BLACK);
            tf5.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 125000 pounds");
            System.exit(0);
        }
        if (callquestion == 14 && tf5.isFocusable()) {
            tf5.setOpaque(true);
            tf5.setForeground(BLACK);
            tf5.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 2500000 pounds");
            System.exit(0);
        }
        if (callquestion == 15 && tf5.isFocusable()) {
            tf5.setOpaque(true);
            tf5.setForeground(BLACK);
            tf5.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 500000 pounds");
            System.exit(0);
        }
    }//GEN-LAST:event_tf5MouseClicked

    private void tf4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tf4MouseClicked
        // TODO add your handling code here:
        if (callquestion == 1 && tf4.isFocusable()) {
            tf4.setOpaque(true);
            tf4.setForeground(BLACK);
            tf4.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 00.0 pounds");
            System.exit(0);
        }

        if (callquestion == 2 && tf4.isFocusable()) {
            tf4.setOpaque(true);
            tf4.setForeground(BLACK);
            tf4.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 100 pounds");
            System.exit(0);
        }
        if (callquestion == 3 && tf4.isFocusable()) {
            tf4.setOpaque(true);
            tf4.setForeground(BLACK);
            tf4.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 200 pounds");
            System.exit(0);
        }

        if (callquestion == 4 && tf4.isFocusable()) {
            tf4.setOpaque(true);
            tf4.setForeground(BLACK);
            tf4.setBackground(GREEN);

            tf2.setOpaque(true);
            tf2.setForeground(WHITE);
            tf2.setBackground(BLACK);

            tf3.setOpaque(true);
            tf3.setForeground(WHITE);
            tf3.setBackground(BLACK);

            tf5.setOpaque(true);
            tf5.setForeground(WHITE);
            tf5.setBackground(BLACK);

            ImageIcon[] imagesList = new ImageIcon[1];
            for (int i = 0; i < imagesList.length; i++) {
                imagesList[i] = new ImageIcon(getClass().getResource("/Millionaire/image/" + imCorrect3[i]));
            }
            if (correct3 < 0) {
                correct3 = 1;
            }
            if (correct3 >= 0 && correct3 < imCorrect3.length) {
                jLabel4.setIcon(imagesList[correct3]);

                correct3++;
            }
        }
        if (callquestion == 5 && tf4.isFocusable()) {
            tf4.setOpaque(true);
            tf4.setForeground(BLACK);
            tf4.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 500 pounds");
            System.exit(0);
        }
        if (callquestion == 6 && tf4.isFocusable()) {
            tf4.setOpaque(true);
            tf4.setForeground(BLACK);
            tf4.setBackground(GREEN);

            tf2.setOpaque(true);
            tf2.setForeground(WHITE);
            tf2.setBackground(BLACK);

            tf3.setOpaque(true);
            tf3.setForeground(WHITE);
            tf3.setBackground(BLACK);

            tf5.setOpaque(true);
            tf5.setForeground(WHITE);
            tf5.setBackground(BLACK);

            ImageIcon[] imagesList = new ImageIcon[1];
            for (int i = 0; i < imagesList.length; i++) {
                imagesList[i] = new ImageIcon(getClass().getResource("/Millionaire/image/" + imCorrect5[i]));
            }
            if (correct5 < 0) {
                correct5 = 1;
            }
            if (correct5 >= 0 && correct5 < imCorrect5.length) {
                jLabel4.setIcon(imagesList[correct5]);

                correct5++;
            }
        }
        if (callquestion == 7 && tf4.isFocusable()) {
            tf4.setOpaque(true);
            tf4.setForeground(BLACK);
            tf4.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 2000 pounds");
            System.exit(0);
        }
        if (callquestion == 8 && tf4.isFocusable()) {
            tf4.setOpaque(true);
            tf4.setForeground(BLACK);
            tf4.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 4000 pounds");
            System.exit(0);
        }
        if (callquestion == 9 && tf4.isFocusable()) {
            tf4.setOpaque(true);
            tf4.setForeground(BLACK);
            tf4.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 8000 pounds");
            System.exit(0);
        }
        if (callquestion == 10 && tf4.isFocusable()) {
            tf4.setOpaque(true);
            tf4.setForeground(BLACK);
            tf4.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 16000 pounds");
            System.exit(0);
        }
        if (callquestion == 11 && tf4.isFocusable()) {
            tf4.setOpaque(true);
            tf4.setForeground(BLACK);
            tf4.setBackground(GREEN);

            tf2.setOpaque(true);
            tf2.setForeground(WHITE);
            tf2.setBackground(BLACK);

            tf3.setOpaque(true);
            tf3.setForeground(WHITE);
            tf3.setBackground(BLACK);

            tf5.setOpaque(true);
            tf5.setForeground(WHITE);
            tf5.setBackground(BLACK);

            ImageIcon[] imagesList = new ImageIcon[1];
            for (int i = 0; i < imagesList.length; i++) {
                imagesList[i] = new ImageIcon(getClass().getResource("/Millionaire/image/" + imCorrect10[i]));
            }
            if (correct10 < 0) {
                correct10 = 1;
            }
            if (correct10 >= 0 && correct10 < imCorrect10.length) {
                jLabel4.setIcon(imagesList[correct10]);

                correct10++;
            }
        }
        if (callquestion == 12 && tf4.isFocusable()) {
            tf4.setOpaque(true);
            tf4.setForeground(BLACK);
            tf4.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 64000 pounds");
            System.exit(0);
        }
        if (callquestion == 13 && tf4.isFocusable()) {
            tf4.setOpaque(true);
            tf4.setForeground(BLACK);
            tf4.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 125000 pounds");
            System.exit(0);
        }
        if (callquestion == 14 && tf4.isFocusable()) {
            tf4.setOpaque(true);
            tf4.setForeground(BLACK);
            tf4.setBackground(Color.RED);
            JOptionPane.showMessageDialog(this, "You won 250000 pounds");
            System.exit(0);
        }
        if (callquestion == 15 && tf4.isFocusable()) {
            tf4.setOpaque(true);
            tf4.setForeground(BLACK);
            tf4.setBackground(GREEN);

            tf2.setOpaque(true);
            tf2.setForeground(WHITE);
            tf2.setBackground(BLACK);

            tf3.setOpaque(true);
            tf3.setForeground(WHITE);
            tf3.setBackground(BLACK);

            tf5.setOpaque(true);
            tf5.setForeground(WHITE);
            tf5.setBackground(BLACK);

            ImageIcon[] imagesList = new ImageIcon[1];
            for (int i = 0; i < imagesList.length; i++) {
                imagesList[i] = new ImageIcon(getClass().getResource("/Millionaire/image/" + imCorrect14[i]));
            }
            if (correct14 < 0) {
                correct14 = 1;
            }
            if (correct14 >= 0 && correct14 < imCorrect14.length) {
                jLabel4.setIcon(imagesList[correct14]);

                correct14++;
            }
            JOptionPane.showMessageDialog(this, "Congratulations you are millioaire today");

        }

    }//GEN-LAST:event_tf4MouseClicked

    private void tf3MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tf3MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_tf3MouseEntered

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        state = true;
        seconds = 0;
        milliseconds = 0;
        Thread t1 = new Thread() {
            public void run() {
                for (;;) {
                    if (callquestion == 1) {
                        try {
                            sleep(1);
                            if (milliseconds > 1000) {
                                milliseconds = 0;
                                seconds++;
                            }
                            if (seconds > 30) {
                                milliseconds = 0;
                                seconds = 0;
                                JOptionPane.showMessageDialog(null, "you won 00.0 pounds");
                                System.exit(0);
                            }
                            milliseconds++;
                            second.setText("  " + seconds);
                        } catch (Exception e) {

                        }
                    }

                    if (callquestion == 2) {

                        try {
                            sleep(1);
                            if (milliseconds > 1000) {
                                milliseconds = 0;
                                seconds++;
                            }
                            if (seconds > 30) {
                                milliseconds = 0;
                                seconds = 0;
                                JOptionPane.showMessageDialog(null, "you won 100 pounds");
                                System.exit(0);
                            }
                            milliseconds++;
                            second.setText("  " + seconds);
                        } catch (Exception e) {

                        }
                    }
                    if (callquestion == 3) {

                        try {
                            sleep(1);
                            if (milliseconds > 1000) {
                                milliseconds = 0;
                                seconds++;
                            }
                            if (seconds > 30) {
                                milliseconds = 0;
                                seconds = 0;
                                JOptionPane.showMessageDialog(null, "you won 200 pounds");
                                System.exit(0);
                            }
                            milliseconds++;
                            second.setText("  " + seconds);
                        } catch (Exception e) {

                        }
                    }
                    if (callquestion == 4) {

                        try {
                            sleep(1);
                            if (milliseconds > 1000) {
                                milliseconds = 0;
                                seconds++;
                            }
                            if (seconds > 30) {
                                milliseconds = 0;
                                seconds = 0;
                                JOptionPane.showMessageDialog(null, "you won 300 pounds");
                                System.exit(0);
                            }
                            milliseconds++;
                            second.setText("  " + seconds);
                        } catch (Exception e) {

                        }
                    }
                    if (callquestion == 5) {

                        try {
                            sleep(1);
                            if (milliseconds > 1000) {
                                milliseconds = 0;
                                seconds++;
                            }
                            if (seconds > 30) {
                                milliseconds = 0;
                                seconds = 0;
                                JOptionPane.showMessageDialog(null, "you won 500 pounds");
                                System.exit(0);
                            }
                            milliseconds++;
                            second.setText("  " + seconds);
                        } catch (Exception e) {

                        }
                    }
                    if (callquestion == 6) {

                        try {
                            sleep(1);
                            if (milliseconds > 1000) {
                                milliseconds = 0;
                                seconds++;
                            }
                            if (seconds > 30) {
                                milliseconds = 0;
                                seconds = 0;
                                JOptionPane.showMessageDialog(null, "you won 1000 pounds");
                                System.exit(0);
                            }
                            milliseconds++;
                            second.setText("  " + seconds);
                        } catch (Exception e) {

                        }
                    }
                }
            }
        };
        t1.start();

    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Millionaire.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Millionaire.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Millionaire.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Millionaire.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Millionaire().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel second;
    private javax.swing.JTextField tf1;
    private javax.swing.JTextField tf2;
    private javax.swing.JTextField tf3;
    private javax.swing.JTextField tf4;
    private javax.swing.JTextField tf5;
    // End of variables declaration//GEN-END:variables
}
